<?php

$users = [
    "UOO1" => [
        "name" => "Ayanda",
        "borrowedBooks" => [
            ["title" => "Programming PHP", "category" => "Textbooks", "daysBorrowed" => 5]
        ],
        "fine" => 0
    ],
    "UOO2" => [
        "name" => "Simanga",
        "borrowedBooks" => [],
        "fine" => 220
    ],
];

$bookRates = [
    "Textbooks" => 5,
    "Journals" => 3,
    "Reference book" => 10 
];

function calculateFine($category, $daysBorrowed, $bookRates) {
    $allowedDays = 7;
    if ($daysBorrowed > $allowedDays) {
        $lateDays = $daysBorrowed - $allowedDays;
        return $lateDays * $bookRates[$category];
    }
    return 0;
}

function borrowBook(&$users, $userId, $title, $category, $daysBorrowed, $bookRates){
    if ($users[$userId]["fine"] > 200) {
        echo "{$users[$userId]['name']} cannot borrow the book due to the fine.\n";
        return;    
    }

    $users[$userId]["borrowedBooks"][] = [
        "title" => $title,
        "category" => $category,
        "daysBorrowed" => $daysBorrowed
    ];

    echo "{$users[$userId]['name']} borrows $title.\n";
}

function returnBook(&$users, $userId, $title, $bookRates) {
    foreach ($users[$userId]["borrowedBooks"] as $index => $book) {
        if ($book["title"] === $title) {
            $fine = calculateFine($book["category"], $book["daysBorrowed"], $bookRates);
            $users[$userId]["fine"] += $fine;
            unset($users[$userId]["borrowedBooks"][$index]);
            echo "{$users[$userId]['name']} returned $title. Fine: R$fine\n";
            return;
        }
    }
}

function printUserSummary ($users, $userId) {
    echo "User: {$users[$userId]['name']}\n";
    echo "Outstanding Fine: R{$users[$userId]['fine']}\n";
    echo "Borrowed Books:\n";
    foreach ($users[$userId]["borrowedBooks"] as $book) {
        echo "-- {$book['title']} ({$book['category']}), {$book['daysBorrowed']} days\n";
    }
    echo "\n";
}

// Test calls for borrowing a book
borrowBook($users, "UOO1", "Programming PHP", "Textbooks", 10, $bookRates);
borrowBook($users, "UOO2", "Cloud computing", "Reference book", 5, $bookRates);
borrowBook($users, "UOO1", "Database Systems", "Journals", 6, $bookRates);

printUserSummary($users, "UOO1");
printUserSummary($users, "UOO2");

?>
