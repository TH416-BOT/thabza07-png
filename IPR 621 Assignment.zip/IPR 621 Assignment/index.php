<?php
// ---------- Parking Permit Module ----------
const STUDENT_PERMIT = 450;
const STAFF_PERMIT   = 750;
const VISITOR_PERMIT = 100;
const MAX_CAPACITY   = 100;

$permitsSold = ["Student" => 0, "Staff" => 0, "Visitor" => 0];
$totalRevenue = 0;

function issuePermit(&$permitsSold, &$totalRevenue, $name, $age, $type) {
    if ($age < 18) {
        echo " Permit cannot be issued to $name (under 18).\n";
        return;
    }
    if (array_sum($permitsSold) >= MAX_CAPACITY) {
        echo "Parking capacity reached. No more permits available.\n";
        return;
    }

    switch ($type) {
        case "Student":
            $permitsSold["Student"]++;
            $totalRevenue += STUDENT_PERMIT;
            break;
        case "Staff":
            $permitsSold["Staff"]++;
            $totalRevenue += STAFF_PERMIT;
            break;
        case "Visitor":
            $permitsSold["Visitor"]++;
            $totalRevenue += VISITOR_PERMIT;
            break;
        default:
            echo " Invalid permit type.\n";
            return;
    }
    echo " Permit issued to $name ($type).\n";
}

function displayPermitSummary($permitsSold, $totalRevenue) {
    echo "\n--- Parking Permit Summary ---\n";
    foreach ($permitsSold as $type => $count) {
        echo "$type Permits: $count\n";
    }
    echo "Total Revenue: R$totalRevenue\n";
}

// ---------- Library Module ----------
$users = [
    "U001" => ["name" => "Ayanda", "borrowedBooks" => [], "fine" => 0],
    "U002" => ["name" => "Simanga", "borrowedBooks" => [], "fine" => 220]
];

$bookRates = ["Textbooks" => 5, "Journals" => 3, "Reference Books" => 10];

function calculateFine($category, $daysBorrowed, $bookRates) {
    $allowedDays = 7;
    if ($daysBorrowed > $allowedDays) {
        $lateDays = $daysBorrowed - $allowedDays;
        return $lateDays * $bookRates[$category];
    }
    return 0;
}

function borrowBook(&$users, $userId, $title, $category, $daysBorrowed, $bookRates) {
    if ($users[$userId]["fine"] > 200) {
        echo " {$users[$userId]['name']} cannot borrow due to outstanding fine.\n";
        return;
    }
    $users[$userId]["borrowedBooks"][] = [
        "title" => $title,
        "category" => $category,
        "daysBorrowed" => $daysBorrowed
    ];
    echo " {$users[$userId]['name']} borrowed $title.\n";
}

function returnBook(&$users, $userId, $title, $bookRates) {
    foreach ($users[$userId]["borrowedBooks"] as $index => $book) {
        if ($book["title"] === $title) {
            $fine = calculateFine($book["category"], $book["daysBorrowed"], $bookRates);
            $users[$userId]["fine"] += $fine;
            unset($users[$userId]["borrowedBooks"][$index]);
            echo "{$users[$userId]['name']} returned $title. Fine: R$fine\n";
            return;
        }
    }
    echo " Book not found.\n";
}

function printUserSummary($users, $userId) {
    echo "\n--- User Summary ---\n";
    echo "User: {$users[$userId]['name']}\n";
    echo "Outstanding Fine: R{$users[$userId]['fine']}\n";
    echo "Borrowed Books:\n";
    foreach ($users[$userId]["borrowedBooks"] as $book) {
        echo "- {$book['title']} ({$book['category']}), {$book['daysBorrowed']} days\n";
    }
}

// ---------- Student Performance Module ----------
$students = [
    "Thabo" => [70, 80, 65, 90, 75, 85],
    "Lerato" => [50, 55, 60, 45, 70, 65],
    "Sipho" => [30, 40, 35, 25, 50, 45],
    "Nomsa" => [85, 90, 88, 92, 95, 89]
];

function calculateAverage($marks) {
    return array_sum($marks) / count($marks);
}

function assignResult($average) {
    if ($average >= 75) return "Distinction";
    elseif ($average >= 50) return "Pass";
    else return "Fail";
}

function classStatistics($students) {
    $averages = [];
    foreach ($students as $name => $marks) {
        $averages[$name] = calculateAverage($marks);
    }
    $highest = max($averages);
    $lowest = min($averages);
    $classAvg = array_sum($averages) / count($averages);

    echo "\n--- Class Statistics ---\n";
    echo "Highest Average: $highest\n";
    echo "Lowest Average: $lowest\n";
    echo "Class Average: $classAvg\n";
}

function topStudent($students) {
    $topName = "";
    $topAvg = 0;
    foreach ($students as $name => $marks) {
        $avg = calculateAverage($marks);
        if ($avg > $topAvg) {
            $topAvg = $avg;
            $topName = $name;
        }
    }
    echo "Top Student: $topName with average $topAvg\n";
}


echo "===== Main Menu =====\n";
echo "1. Parking Permit Management\n";
echo "2. Library Borrowing & Fine Management\n";
echo "3. Student Performance Analytics\n";

// Example runs (replace with user input handling if needed)
echo "\n--- Demo Run ---\n";

// Parking demo
issuePermit($permitsSold, $totalRevenue, "John", 20, "Student");
issuePermit($permitsSold, $totalRevenue, "Mary", 17, "Staff");
displayPermitSummary($permitsSold, $totalRevenue);

// Library demo
borrowBook($users, "U001", "Programming PHP", "Textbooks", 10, $bookRates);
returnBook($users, "U001", "Programming PHP", $bookRates);
printUserSummary($users, "U001");

// Student demo
foreach ($students as $name => $marks) {
    $avg = calculateAverage($marks);
    $result = assignResult($avg);
    echo "$name - Average: $avg, Result: $result\n";
}
classStatistics($students);
topStudent($students);

?>
