<?php

//Declaring Variables 
define("Student", 450);
define("Staff", 750);
define("Visitor", 100);
define("MAX_CAPACITY", 100);

//arrays
$totalSales = [
    "Student" => 0,
    "Staff" => 0,
    "Visitor" => 0
];

// Storing permits
$permits = [];

$applications = [
    //Student
    ["name" => "Ben", "age" => 20, "type" => "Student"],
    //Staff
    ["name" => "Azande", "age" => 40, "type" => "Staff"],
    //Visitor
    ["name" => "Daniel", "age" => 18, "type" => "Visitor"],
];

//conditional statements
foreach($applications as $app) {
    if (count($permits) == MAX_CAPACITY) {
        echo "Parking permit reached, No permit may be issued. <br>";
        break;
    }

    //Checking if the student, staff and visitor is given a permit
    if ($app["age"] < 18) {
        echo "Permit is denied for {$app["name"]} (under the age of 18.)<br>";
        continue;
    }

    switch ($app["type"]) {
        case "Student":
            $price = Student;
            break;
        case "Staff":
            $price = Staff;
            break;
        case "Visitor":
            $price = Visitor;
            break;
        default:
            echo "Invalid permit type {$app["name"]} {$app["type"]}";
            continue 2;
    }

    $permits[] = [
        "name" => $app["name"],
        "type" => $app["type"],
        "price" => $price,
    ];
}

$studentCount = 0;
$staffCount = 0;
$visitorCount = 0;
$totalRevenue = 0;

foreach ($permits as $permit) {
    switch ($permit["type"]) {
        case "Student":
            $studentCount++;
            break;
        case "Staff":
            $staffCount++;
            break;
        case "Visitor":
            $visitorCount++;
            break;
    }

    $totalRevenue += $permit["price"];
}

// Summary
echo "<hr>";
echo "Summary: <br>";
echo "Student permit sold: {$studentCount} <br>";
echo "Staff permit sold: {$staffCount} <br>";
echo "Visitor's permit sold: {$visitorCount} <br>";
echo "------------------------- <br>";
echo "Total Revenue: {$totalRevenue}";
?>
