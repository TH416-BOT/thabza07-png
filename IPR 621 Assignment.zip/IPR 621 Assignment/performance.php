<?php

$students = [
    ["name" => "Alice", "marks" => [65, 50, 82, 90, 74, 59]],
    ["name" => "Andile", "marks" => [75, 56, 70, 85, 73, 53]],
    ["name" => "Nathi", "marks" => [90, 86, 75, 60, 55, 69]],
    ["name" => "Charles", "marks" => [65, 90, 79, 86, 68, 70]]
];

function validateMarks($marks) {
    foreach ($marks as $mark) {
        if ($mark < 0 || $mark > 100) {
            return false;
        }
    }
    return true;
}

function calculateAverage($marks) {
    return array_sum($marks) / count($marks);
}

function calculateResult($average) {
    if ($average >= 75) return "Distinction";
    else if ($average >= 50) return "Pass";
    else return "Fail";

}

$topStudent = null;
$highestAverage = 0;
$classAverages = [];

foreach ($students as $student) {
    if (!validateMarks($student["marks"])) {
        echo "Invalid marks for {$student['name']}";
        continue;
    }

    $avg = calculateAverage($student["marks"]);
    $result = calculateResult($avg);

    //showing student marks in the list
    $marksList = implode(", ", $student["marks"]);



echo "Name: {$student['name']}\n";
echo "Marks: [$marksList]\n";
echo "Average: $avg\n";
echo "Result: $result\n";
echo "-------------\n";

echo $student['name'] . " - Marks: [$marksList] - Average: $avg - Result: $result\n";

$classAverages[] = $avg;

if ($avg > $highestAverage) {
    $highestAverage = $avg;
    $topStudent = $student["name"];
    }
}


echo "\n Class Marks:\n";
echo "\n Summary: \n";
echo "Highest Average: " .max($classAverages). "\n";
echo "Lowest Average: " .min($classAverages). "\n";
echo "Class Average: " . (array_sum($classAverages) / count($classAverages)) . "\n";
echo "Top Student: $topStudent\n";



?>